type UpdateAssetParams = {
  id: number
  action: 'checkOut' | 'return' | 'maintenance' | 'retire'
}

type AssetRow = {
  id: number
  name: string
  status: string
  assigned_to: string | null
}

export default async function updateAsset(req: { params: UpdateAssetParams; user: User }) {
  const [profileResult, assetResult] = await Promise.all([
    retoolDb.query<{ role: string }>('SELECT role FROM users WHERE email = $1 LIMIT 1', [req.user.email]),
    retoolDb.query<AssetRow>('SELECT id, name, status, assigned_to FROM equipment_assets WHERE id = $1 LIMIT 1', [req.params.id]),
  ])
  const asset = assetResult.data[0]
  if (!asset) throw new Error('Asset not found.')

  const role = profileResult.data[0]?.role ?? 'Standard User'
  const isManager = role === 'Inventory Manager' || role === 'Admin'
  const isAdmin = role === 'Admin'
  const isAssignedUser = asset.assigned_to?.toLowerCase() === req.user.email.toLowerCase()

  let status: string
  let assignedTo: string | null
  if (req.params.action === 'checkOut') {
    if (asset.status !== 'Available') throw new Error('Only available assets can be checked out.')
    status = 'Checked Out'
    assignedTo = req.user.email
  } else if (req.params.action === 'return') {
    if (!isAssignedUser && !isAdmin) throw new Error('Only the assigned user or an Admin can return this asset.')
    status = 'Available'
    assignedTo = null
  } else {
    if (!isManager) throw new Error('Only Inventory Managers and Admins can change asset lifecycle status.')
    status = req.params.action === 'maintenance' ? 'Under Maintenance' : 'Retired'
    assignedTo = null
  }

  const actionLabel = req.params.action === 'checkOut' ? 'Checked out' : req.params.action === 'return' ? 'Returned' : req.params.action === 'maintenance' ? 'Sent to maintenance' : 'Retired'
  const result = await retoolDb.query(
    `UPDATE equipment_assets
     SET status = $1, assigned_to = $2, audit_log = $3
     WHERE id = $4
     RETURNING id, asset_tag, name, category, status, assigned_to, value, audit_log, created_at`,
    [status, assignedTo, `${actionLabel} by ${req.user.fullName || req.user.email}`, asset.id],
  )
  return result.data[0]
}
