type Params = Record<string, never>

type RequestRow = {
  id: number
  asset_id: number
  requester_email: string
  category: string
  asset_name: string
  comments: string
  status: string
  requested_at: string
}

export default async function getRequests(req: { params: Params; user: User }) {
  const roleResult = await retoolDb.query<{ role: string }>(
    'SELECT role FROM users WHERE email = $1 LIMIT 1',
    [req.user.email],
  )
  const role = roleResult.data[0]?.role ?? 'Standard User'
  const isManager = role === 'Inventory Manager' || role === 'Admin'

  const result = isManager
    ? await retoolDb.query<RequestRow>(
        `SELECT id, asset_id, requester_email, category, asset_name, comments, status, requested_at
         FROM equipment_requests WHERE status = 'Pending Review'
         ORDER BY requested_at DESC`,
      )
    : await retoolDb.query<RequestRow>(
        `SELECT id, asset_id, requester_email, category, asset_name, comments, status, requested_at
         FROM equipment_requests WHERE requester_email = $1
         ORDER BY requested_at DESC`,
        [req.user.email],
      )

  return {
    scope: isManager ? 'pending-review' : 'own',
    requests: result.data.map((row) => ({
      id: row.id,
      assetId: row.asset_id,
      requesterEmail: row.requester_email,
      category: row.category,
      assetName: row.asset_name,
      comments: row.comments,
      status: row.status,
      requestedAt: row.requested_at,
    })),
  }
}
