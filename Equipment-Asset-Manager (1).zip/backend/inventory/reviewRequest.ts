type ReviewRequestParams = {
  requestId: number
  decision: 'approve' | 'reject'
}

type RequestRow = {
  id: number
  asset_id: number
  requester_email: string
  asset_name: string
  status: string
}

export default async function reviewRequest(req: { params: ReviewRequestParams; user: User }) {
  const roleResult = await retoolDb.query<{ role: string }>(
    'SELECT role FROM users WHERE email = $1 LIMIT 1',
    [req.user.email],
  )
  const role = roleResult.data[0]?.role
  if (role !== 'Inventory Manager' && role !== 'Admin') {
    throw new Error('Only Inventory Managers and Admins can review requests.')
  }

  const requestResult = await retoolDb.query<RequestRow>(
    'SELECT id, asset_id, requester_email, asset_name, status FROM equipment_requests WHERE id = $1 LIMIT 1',
    [req.params.requestId],
  )
  const request = requestResult.data[0]
  if (!request) throw new Error('Request not found.')
  if (request.status !== 'Pending Review') {
    // Double-clicks or duplicate reviews land here — respond gracefully instead of erroring.
    return { ...request, alreadyProcessed: true }
  }

  if (req.params.decision === 'approve') {
    const assetResult = await retoolDb.query<{ status: string }>(
      'SELECT status FROM equipment_assets WHERE id = $1 LIMIT 1',
      [request.asset_id],
    )
    if (assetResult.data[0]?.status !== 'Requested') {
      throw new Error('Asset is no longer awaiting review.')
    }
    const updatedRequest = await retoolDb.query(
      `UPDATE equipment_requests SET status = 'Fulfilled' WHERE id = $1 RETURNING id, asset_id, asset_name, status, requester_email`,
      [request.id],
    )
    await retoolDb.query(
      `UPDATE equipment_assets SET status = 'Checked Out', assigned_to = $1, audit_log = $2 WHERE id = $3`,
      [request.requester_email, `Request approved by ${req.user.fullName || req.user.email} — assigned to ${request.requester_email}`, request.asset_id],
    )
    return updatedRequest.data[0]
  }

  const rejected = await retoolDb.query(
    `UPDATE equipment_requests SET status = 'Rejected' WHERE id = $1 RETURNING id, asset_id, asset_name, status, requester_email`,
    [request.id],
  )
  await retoolDb.query(
    `UPDATE equipment_assets SET status = 'Available', audit_log = $1 WHERE id = $2 AND status = 'Requested'`,
    [`Request rejected by ${req.user.fullName || req.user.email}`, request.asset_id],
  )
  return rejected.data[0]
}
