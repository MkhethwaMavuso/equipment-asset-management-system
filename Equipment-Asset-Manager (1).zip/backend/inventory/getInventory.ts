type Params = Record<string, never>

type AssetRow = {
  id: number
  asset_tag: string
  name: string
  category: string
  status: string
  assigned_to: string | null
  value: string | number
  audit_log: string
  created_at: string
}

type UserRow = {
  full_name: string
  role: string
}

export default async function getInventory(req: { params: Params; user: User }) {
  const profileResult = await retoolDb.query<UserRow>(
    `SELECT full_name, role FROM users WHERE email = $1 LIMIT 1`,
    [req.user.email],
  )
  const profile = profileResult.data[0]
  const role = profile?.role === 'Inventory Manager' || profile?.role === 'Admin'
    ? profile.role
    : 'Standard User'
  const isManager = role === 'Inventory Manager' || role === 'Admin'
  const assetResult = await retoolDb.query<AssetRow>(
    `SELECT id, asset_tag, name, category, status, assigned_to, value, audit_log, created_at
     FROM equipment_assets
     WHERE $1::boolean OR assigned_to = $2
     ORDER BY created_at DESC, id DESC`,
    [isManager, req.user.email],
  )

  return {
    profile: {
      fullName: profile?.full_name ?? req.user.fullName ?? req.user.email,
      email: req.user.email,
      role,
    },
    assets: assetResult.data.map((asset) => ({
      id: asset.id,
      assetTag: asset.asset_tag,
      name: asset.name,
      category: asset.category,
      status: asset.status,
      assignedTo: asset.assigned_to,
      value: Number(asset.value),
      auditLog: asset.audit_log,
      createdAt: asset.created_at,
    })),
  }
}
