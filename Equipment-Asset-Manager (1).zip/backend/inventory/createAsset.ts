type CreateAssetParams = {
  name: string
  category: string
  value: number
  assignedTo?: string
}

const categories = ['Computing', 'Machinery', 'Vehicles', 'Office Hardware']

export default async function createAsset(req: { params: CreateAssetParams; user: User }) {
  const roleResult = await retoolDb.query<{ role: string }>(
    'SELECT role FROM users WHERE email = $1 LIMIT 1',
    [req.user.email],
  )
  const role = roleResult.data[0]?.role
  if (role !== 'Inventory Manager' && role !== 'Admin') {
    throw new Error('Only Inventory Managers and Admins can register assets.')
  }
  if (!categories.includes(req.params.category)) {
    throw new Error('Invalid asset category.')
  }

  const assignedTo = req.params.assignedTo?.trim() || null
  if (assignedTo) {
    const assignee = await retoolDb.query<{ email: string }>('SELECT email FROM users WHERE email = $1 LIMIT 1', [assignedTo])
    if (!assignee.data[0]) {
      throw new Error('Assignment email does not belong to a user profile.')
    }
  }

  // Asset tag is generated server-side from a dedicated sequence, so it is
  // always unique and free of manual input errors.
  const result = await retoolDb.query(
    `INSERT INTO equipment_assets (asset_tag, name, category, status, assigned_to, value, audit_log)
     VALUES (
       generate_asset_tag(
         CASE $1
           WHEN 'Computing' THEN 'CMP'
           WHEN 'Machinery' THEN 'MCH'
           WHEN 'Vehicles' THEN 'VHC'
           WHEN 'Office Hardware' THEN 'OFF'
           ELSE 'AST'
         END
       ),
       $2, $3, $4, $5, $6, $7
     )
     RETURNING id, asset_tag, name, category, status, assigned_to, value, audit_log, created_at`,
    [
      req.params.category,
      req.params.name.trim(),
      req.params.category,
      assignedTo ? 'Checked Out' : 'Available',
      assignedTo,
      req.params.value,
      `Registered by ${req.user.fullName || req.user.email}`,
    ],
  )
  return result.data[0]
}
