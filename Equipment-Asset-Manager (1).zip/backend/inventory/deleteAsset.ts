type DeleteAssetParams = {
  id: number
}

export default async function deleteAsset(req: { params: DeleteAssetParams; user: User }) {
  const roleResult = await retoolDb.query<{ role: string }>(
    'SELECT role FROM users WHERE email = $1 LIMIT 1',
    [req.user.email],
  )
  const role = roleResult.data[0]?.role
  if (role !== 'Inventory Manager' && role !== 'Admin') {
    throw new Error('Only Inventory Managers and Admins can delete assets.')
  }

  // Requests reference the asset, so remove them first to satisfy the foreign key.
  await retoolDb.query('DELETE FROM equipment_requests WHERE asset_id = $1', [req.params.id])
  const result = await retoolDb.query<{ id: number; asset_tag: string }>(
    'DELETE FROM equipment_assets WHERE id = $1 RETURNING id, asset_tag',
    [req.params.id],
  )
  const deleted = result.data[0]
  if (!deleted) {
    // Repeat clicks on an already-removed row land here — respond gracefully instead of erroring.
    return { id: req.params.id, alreadyDeleted: true }
  }
  return deleted
}
