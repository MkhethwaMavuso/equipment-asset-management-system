type UpdateDetailsParams = {
  id: number
  name: string
  category: string
  value: number
}

const categories = ['Computing', 'Machinery', 'Vehicles', 'Office Hardware']

export default async function updateAssetDetails(req: { params: UpdateDetailsParams; user: User }) {
  const roleResult = await retoolDb.query<{ role: string }>(
    'SELECT role FROM users WHERE email = $1 LIMIT 1',
    [req.user.email],
  )
  const role = roleResult.data[0]?.role
  if (role !== 'Inventory Manager' && role !== 'Admin') {
    throw new Error('Only Inventory Managers and Admins can edit assets.')
  }
  if (!categories.includes(req.params.category)) {
    throw new Error('Invalid asset category.')
  }

  const result = await retoolDb.query(
    `UPDATE equipment_assets
     SET name = $1, category = $2, value = $3, audit_log = $4
     WHERE id = $5
     RETURNING id, asset_tag, name, category, status, assigned_to, value, audit_log, created_at`,
    [req.params.name.trim(), req.params.category, req.params.value, `Details updated by ${req.user.fullName || req.user.email}`, req.params.id],
  )
  const updated = result.data[0]
  if (!updated) throw new Error('Asset not found.')
  return updated
}
