type AvailableAssetParams = {
  category: string
}

const categories = ['Computing', 'Machinery', 'Vehicles', 'Office Hardware']

export default async function getAvailableAssets(req: { params: AvailableAssetParams; user: User }) {
  if (!categories.includes(req.params.category)) throw new Error('Invalid asset category.')
  const result = await retoolDb.query<{ id: number; name: string; asset_tag: string }>(
    `SELECT id, name, asset_tag FROM equipment_assets
     WHERE category = $1 AND status = 'Available'
     ORDER BY name`,
    [req.params.category],
  )
  return result.data.map((row) => ({ id: row.id, name: row.name, assetTag: row.asset_tag }))
}
