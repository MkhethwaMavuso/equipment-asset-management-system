type SubmitRequestParams = {
  assetId: number
  comments: string
}

type RequestRow = {
  id: number
  asset_id: number
  asset_name: string
  status: string
}

export default async function submitRequest(req: { params: SubmitRequestParams; user: User }) {
  const comments = req.params.comments.trim()
  if (!comments) throw new Error('A request comment is required.')

  // Atomic: only flips the asset to 'Requested' when it is still 'Available',
  // and inserts the request row from the same updated row.
  const result = await retoolDb.query<RequestRow>(
    `WITH updated AS (
       UPDATE equipment_assets
       SET status = 'Requested'
       WHERE id = $1 AND status = 'Available'
       RETURNING id, name, category
     )
     INSERT INTO equipment_requests (asset_id, requester_email, category, asset_name, comments)
     SELECT id, $2, category, name, $3 FROM updated
     RETURNING id, asset_id, asset_name, status`,
    [req.params.assetId, req.user.email, comments],
  )
  const request = result.data[0]
  if (!request) throw new Error('Asset is no longer available for request.')
  return request
}
