import InventoryOperations from './pages/InventoryOperations'

export default function App() {
  return <InventoryOperations />
}
