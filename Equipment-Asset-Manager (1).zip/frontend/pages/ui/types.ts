export type Role = 'Standard User' | 'Inventory Manager' | 'Admin'
export type Status = 'Available' | 'Requested' | 'Checked Out' | 'Under Maintenance' | 'Retired'
export type Category = 'Computing' | 'Machinery' | 'Vehicles' | 'Office Hardware'

export type Profile = {
  fullName: string
  email: string
  role: Role
}

export type Asset = {
  id: number
  assetTag: string
  name: string
  category: Category
  status: Status
  assignedTo: string | null
  value: number
  auditLog: string
  createdAt: string
}

export type RequestRecord = {
  id: number
  assetId: number
  requesterEmail: string
  category: string
  assetName: string
  comments: string
  status: string
  requestedAt: string
}

export type AvailableAsset = {
  id: number
  name: string
  assetTag: string
}

export const categories: Category[] = ['Computing', 'Machinery', 'Vehicles', 'Office Hardware']
export const statuses: Status[] = ['Available', 'Requested', 'Checked Out', 'Under Maintenance', 'Retired']

export function isManagerRole(role: Role): boolean {
  return role === 'Inventory Manager' || role === 'Admin'
}

export function statusClass(status: Status): string {
  if (status === 'Available') return 'bg-success/15 text-success border-success/30'
  if (status === 'Requested') return 'bg-warning/15 text-warning-foreground border-warning/30'
  if (status === 'Checked Out') return 'bg-primary/10 text-foreground border-primary/20'
  if (status === 'Under Maintenance') return 'bg-destructive/10 text-destructive border-destructive/30'
  return 'bg-muted text-muted-foreground border-border'
}

export function metricValue(value: number): string {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value)
}
