import { useEffect, useState, type FormEvent } from 'react'
import { CheckCircle2, PackageSearch, Send } from 'lucide-react'
import { useGetAvailableAssets, useGetRequests, useSubmitRequest } from '../../hooks/backend/inventory'
import { toast } from '../../lib/shadcn/sonner'
import { Badge } from '../../lib/shadcn/badge'
import { Button } from '../../lib/shadcn/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../lib/shadcn/card'
import { Label } from '../../lib/shadcn/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../lib/shadcn/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../lib/shadcn/table'
import { Textarea } from '../../lib/shadcn/textarea'
import { categories, statusClass, type AvailableAsset, type Category, type Profile, type RequestRecord, type Status } from './types'

type Props = {
  profile: Profile
  onRefresh: () => void
}

function requestBadgeClass(status: string): string {
  if (status === 'Fulfilled') return statusClass('Available' as Status)
  if (status === 'Rejected') return 'bg-destructive/10 text-destructive border-destructive/30'
  return statusClass('Requested' as Status)
}

export default function RequestPortal({ profile, onRefresh }: Props) {
  const { data: availableData, loading: assetsLoading, error: availableError, trigger: loadAvailable } = useGetAvailableAssets()
  const { data: myRequestData, loading: requestsLoading, trigger: loadMyRequests } = useGetRequests()
  const { trigger: submitRequest, loading: submitting } = useSubmitRequest()
  const [category, setCategory] = useState<Category | ''>('')
  const [assetId, setAssetId] = useState('')
  const [comments, setComments] = useState('')
  const availableAssets = (availableData ?? []) as AvailableAsset[]
  const myRequests = (myRequestData?.requests ?? []) as RequestRecord[]

  useEffect(() => {
    void loadMyRequests()
  }, [loadMyRequests])

  useEffect(() => {
    if (category) {
      setAssetId('')
      void loadAvailable({ category })
    }
  }, [category, loadAvailable])

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault()
    if (!category || !assetId || !comments.trim()) return
    const selected = availableAssets.find((asset) => String(asset.id) === assetId)
    try {
      const response = await submitRequest({ assetId: Number(assetId), comments: comments.trim() })
      if (response.result) {
        toast.success(`Request submitted for ${selected?.name ?? 'asset'} — pending review.`)
      } else if (response.error) {
        toast.error(response.error)
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Request submission failed.')
    } finally {
      setComments('')
      setAssetId('')
      setCategory('')
      await loadMyRequests(undefined, { skipCache: true })
      onRefresh()
    }
  }

  return <div className="space-y-6">
    <section className="flex flex-col justify-between gap-3 md:flex-row md:items-end">
      <div><p className="text-sm font-medium text-primary">Request portal</p><h2 className="mt-1 text-3xl font-semibold tracking-tight">Request equipment</h2><p className="mt-1 text-sm text-muted-foreground">Pick a category, choose an available asset, and submit it for review.</p></div>
      <div className="flex items-center gap-2 text-xs text-muted-foreground"><PackageSearch className="size-3.5" /> Requests route to Inventory Managers</div>
    </section>
    <section className="grid gap-6 xl:grid-cols-[420px_minmax(0,1fr)]">
      <Card className="h-fit shadow-retool-sm">
        <CardHeader className="border-b border-border"><div><CardTitle className="text-base">Request equipment form</CardTitle><CardDescription>Four steps: category, asset, comments, submit.</CardDescription></div></CardHeader>
        <CardContent className="pt-5">
          <form className="space-y-5" onSubmit={(event) => void handleSubmit(event)}>
            <div className="space-y-2"><Label className="text-xs uppercase tracking-wide text-muted-foreground">Step 1 · Category</Label><Select value={category} onValueChange={(value) => setCategory(value as Category)}><SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger><SelectContent>{categories.map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label className="text-xs uppercase tracking-wide text-muted-foreground">Step 2 · Equipment</Label><Select value={assetId} onValueChange={setAssetId} disabled={!category || assetsLoading}><SelectTrigger><SelectValue placeholder={category ? (assetsLoading ? 'Loading available assets…' : 'Select available equipment') : 'Choose a category first'} /></SelectTrigger><SelectContent>{availableAssets.length ? availableAssets.map((asset) => <SelectItem key={asset.id} value={String(asset.id)}>{asset.name} · {asset.assetTag}</SelectItem>) : <div className="px-3 py-2 text-xs text-muted-foreground">No available assets in this category.</div>}</SelectContent></Select>{availableError ? <p className="text-xs text-destructive">{availableError}</p> : null}</div>
            <div className="space-y-2"><Label className="text-xs uppercase tracking-wide text-muted-foreground">Step 3 · Justification</Label><Textarea value={comments} onChange={(event) => setComments(event.target.value)} placeholder="Why do you need this equipment?" className="min-h-28" /></div>
            <Button type="submit" className="w-full gap-2" disabled={!category || !assetId || !comments.trim() || submitting}><Send className="size-4" />{submitting ? 'Submitting…' : 'Step 4 · Submit request'}</Button>
          </form>
        </CardContent>
      </Card>
      <Card className="min-w-0 shadow-retool-sm">
        <CardHeader className="border-b border-border"><div><CardTitle className="text-base">My requests</CardTitle><CardDescription>{requestsLoading ? 'Loading request history…' : `${myRequests.length} requests on file for ${profile.email}`}</CardDescription></div></CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Asset</TableHead><TableHead>Category</TableHead><TableHead>Justification</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
            <TableBody>
              {myRequests.length ? myRequests.map((request) => <TableRow key={request.id}><TableCell><p className="font-medium text-foreground">{request.assetName}</p><p className="text-xs text-muted-foreground">{new Date(request.requestedAt).toLocaleString()}</p></TableCell><TableCell className="text-sm text-muted-foreground">{request.category}</TableCell><TableCell className="max-w-72 truncate text-sm text-muted-foreground">{request.comments}</TableCell><TableCell><Badge variant="outline" className={requestBadgeClass(request.status)}>{request.status === 'Pending Review' ? <><CheckCircle2 className="size-3" /> {request.status}</> : request.status}</Badge></TableCell></TableRow>) : <TableRow><TableCell colSpan={4} className="h-28 text-center text-muted-foreground">You have not submitted any requests yet.</TableCell></TableRow>}
            </TableBody>
          </Table></div>
        </CardContent>
      </Card>
    </section>
  </div>
}
