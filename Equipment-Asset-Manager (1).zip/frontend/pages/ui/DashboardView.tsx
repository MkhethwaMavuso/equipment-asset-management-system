import { useMemo, useState } from 'react'
import {
  ArrowDownUp,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  ClipboardList,
  Construction,
  Hourglass,
  MoreHorizontal,
  Search,
  Wrench,
} from 'lucide-react'
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  type ColumnDef,
  type SortingState,
  useReactTable,
} from '@tanstack/react-table'
import { useUpdateAsset } from '../../hooks/backend/inventory'
import { toast } from '../../lib/shadcn/sonner'
import { Badge } from '../../lib/shadcn/badge'
import { Button } from '../../lib/shadcn/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../lib/shadcn/card'
import { Input } from '../../lib/shadcn/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../lib/shadcn/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../lib/shadcn/table'
import { isManagerRole, metricValue, statuses, statusClass, type Asset, type Category, type Profile } from './types'

type Props = {
  profile: Profile
  assets: Asset[]
  loading: boolean
  onRefresh: () => void
}

export default function DashboardView({ profile, assets, loading, onRefresh }: Props) {
  const isManager = isManagerRole(profile.role)
  const email = profile.email.toLowerCase()
  const { loading: updatingAsset, trigger: persistUpdate } = useUpdateAsset()
  const [sorting, setSorting] = useState<SortingState>([])
  const [globalFilter, setGlobalFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState<'All' | Asset['status']>('All')
  const [categoryFilter, setCategoryFilter] = useState<'All' | Category>('All')

  const metrics = useMemo(() => ({
    total: assets.length,
    value: assets.reduce((sum, asset) => sum + asset.value, 0),
    checkedOut: assets.filter((asset) => asset.status === 'Checked Out').length,
    maintenance: assets.filter((asset) => asset.status === 'Under Maintenance').length,
  }), [assets])

  const applyUpdate = async (id: number, action: 'checkOut' | 'return' | 'maintenance' | 'retire', message: string) => {
    try {
      const response = await persistUpdate({ id, action })
      if (response.result) {
        toast.success(message)
        onRefresh()
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Asset action failed.')
      onRefresh()
    }
  }

  const columns = useMemo<ColumnDef<Asset>[]>(() => [
    { accessorKey: 'assetTag', header: 'Asset tag', cell: ({ row }) => <span className="font-mono text-xs font-semibold">{row.original.assetTag}</span> },
    { accessorKey: 'name', header: 'Asset', cell: ({ row }) => <div><p className="font-medium text-foreground">{row.original.name}</p><p className="text-xs text-muted-foreground">{row.original.category}</p></div> },
    { accessorKey: 'status', header: 'Status', cell: ({ row }) => <Badge variant="outline" className={statusClass(row.original.status)}>{row.original.status}</Badge> },
    { accessorKey: 'assignedTo', header: 'Assigned to', cell: ({ row }) => <span className="text-sm text-muted-foreground">{row.original.assignedTo ?? 'Unassigned'}</span> },
    { accessorKey: 'value', header: 'Value', cell: ({ row }) => <span className="font-medium tabular-nums">{metricValue(row.original.value)}</span> },
    {
      id: 'actions', header: '', enableSorting: false,
      cell: ({ row }) => {
        const asset = row.original
        const canReturn = asset.assignedTo?.toLowerCase() === email || profile.role === 'Admin'
        return <div className="flex justify-end gap-1">
          {asset.status === 'Checked Out' && canReturn ? <Button size="sm" variant="outline" onClick={() => void applyUpdate(asset.id, 'return', `${asset.name} returned.`)} disabled={updatingAsset}>Return</Button> : null}
          {isManager && asset.status === 'Requested' ? <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground"><Hourglass className="size-3.5" /> Pending request</span> : null}
          {isManager && asset.status !== 'Retired' && asset.status !== 'Requested' ? <Button size="icon" variant="ghost" aria-label={`Send ${asset.name} to maintenance`} onClick={() => void applyUpdate(asset.id, 'maintenance', `${asset.name} sent to maintenance.`)} disabled={updatingAsset}><Wrench className="size-4" /></Button> : null}
          {isManager && asset.status !== 'Retired' && asset.status !== 'Requested' ? <Button size="icon" variant="ghost" aria-label={`Retire ${asset.name}`} onClick={() => void applyUpdate(asset.id, 'retire', `${asset.name} retired.`)} disabled={updatingAsset}><MoreHorizontal className="size-4" /></Button> : null}
        </div>
      },
    },
  ], [email, isManager, profile.role, updatingAsset])

  const table = useReactTable({
    data: assets,
    columns,
    state: { sorting, globalFilter },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    globalFilterFn: (row, _columnId, filterValue) => {
      const term = String(filterValue).toLowerCase()
      return [row.original.assetTag, row.original.name, row.original.category, row.original.status, row.original.assignedTo ?? ''].some((value) => value.toLowerCase().includes(term))
    },
  })

  const filteredRows = table.getRowModel().rows.filter((row) => (statusFilter === 'All' || row.original.status === statusFilter) && (categoryFilter === 'All' || row.original.category === categoryFilter))

  return <div className="space-y-6">
    <section className="flex flex-col justify-between gap-3 md:flex-row md:items-end">
      <div><p className="text-sm font-medium text-primary">Inventory workspace</p><h2 className="mt-1 text-3xl font-semibold tracking-tight">Assets at a glance</h2><p className="mt-1 text-sm text-muted-foreground">{isManager ? 'Organization-wide inventory and assignments.' : 'Assets currently assigned to your account.'}</p></div>
      <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="size-2 rounded-full bg-success" /> Role-based data scope active</div>
    </section>
    <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {[
        { label: 'Total assets', value: metrics.total.toString(), detail: isManager ? 'Across organization' : 'Assigned to you', icon: ClipboardList },
        { label: 'Inventory value', value: metricValue(metrics.value), detail: 'Scoped asset valuation', icon: CircleDollarSign },
        { label: 'Currently checked out', value: metrics.checkedOut.toString(), detail: 'In active use', icon: CheckCircle2 },
        { label: 'Under maintenance', value: metrics.maintenance.toString(), detail: 'Requires attention', icon: Construction },
      ].map((metric) => <Card key={metric.label} className="shadow-retool-sm"><CardContent className="flex items-start justify-between p-5"><div><p className="text-sm text-muted-foreground">{metric.label}</p><p className="mt-2 text-2xl font-semibold tracking-tight">{metric.value}</p><p className="mt-1 text-xs text-muted-foreground">{metric.detail}</p></div><div className="rounded-md bg-muted p-2.5"><metric.icon className="size-4 text-muted-foreground" /></div></CardContent></Card>)}
    </section>
    <Card className="min-w-0 shadow-retool-sm">
      <CardHeader className="gap-4 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between"><div><CardTitle className="text-base">Inventory directory</CardTitle><CardDescription>{loading ? 'Loading persisted inventory…' : `${assets.length} records accessible to your role`}</CardDescription></div><div className="flex items-center gap-2 text-xs text-muted-foreground"><ArrowDownUp className="size-3.5" /> Sort columns to refine results</div></CardHeader>
      <CardContent className="p-0">
        <div className="flex flex-col gap-3 border-b border-border p-4 lg:flex-row">
          <div className="relative flex-1"><Search className="pointer-events-none absolute left-3 top-2.5 size-4 text-muted-foreground" /><Input value={globalFilter} onChange={(event) => setGlobalFilter(event.target.value)} placeholder="Search tags, assets, people…" className="pl-9" /></div>
          <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as 'All' | Asset['status'])}><SelectTrigger className="w-full lg:w-44"><SelectValue placeholder="Status" /></SelectTrigger><SelectContent><SelectItem value="All">All statuses</SelectItem>{statuses.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select>
          <Select value={categoryFilter} onValueChange={(value) => setCategoryFilter(value as 'All' | Category)}><SelectTrigger className="w-full lg:w-44"><SelectValue placeholder="Category" /></SelectTrigger><SelectContent><SelectItem value="All">All categories</SelectItem>{(['Computing', 'Machinery', 'Vehicles', 'Office Hardware'] as Category[]).map((category) => <SelectItem key={category} value={category}>{category}</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="overflow-x-auto"><Table><TableHeader>{table.getHeaderGroups().map((headerGroup) => <TableRow key={headerGroup.id}>{headerGroup.headers.map((header) => <TableHead key={header.id} className={header.column.id === 'actions' ? 'text-right' : ''}>{header.isPlaceholder ? null : <button className="inline-flex items-center gap-1 font-medium" onClick={header.column.getToggleSortingHandler()}>{flexRender(header.column.columnDef.header, header.getContext())}{header.column.getCanSort() ? <ArrowDownUp className="size-3" /> : null}</button>}</TableHead>)}</TableRow>)}</TableHeader><TableBody>{filteredRows.length ? filteredRows.map((row) => <TableRow key={row.id}>{row.getVisibleCells().map((cell) => <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>)}</TableRow>) : <TableRow><TableCell colSpan={columns.length} className="h-36 text-center text-muted-foreground">No assets match these filters.</TableCell></TableRow>}</TableBody></Table></div>
        <div className="flex items-center justify-between border-t border-border px-4 py-3"><p className="text-xs text-muted-foreground">Showing {filteredRows.length} of {assets.length} assets</p><div className="flex gap-1"><Button size="icon" variant="outline" aria-label="Previous page" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}><ChevronLeft className="size-4" /></Button><Button size="icon" variant="outline" aria-label="Next page" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}><ChevronRight className="size-4" /></Button></div></div>
      </CardContent>
    </Card>
  </div>
}
