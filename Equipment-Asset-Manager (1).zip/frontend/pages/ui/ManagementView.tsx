import { useEffect, useState, type FormEvent } from 'react'
import { Check, ClipboardCheck, Pencil, PackagePlus, ShieldAlert, Trash2, X } from 'lucide-react'
import { useCreateAsset, useDeleteAsset, useGetRequests, useReviewRequest, useUpdateAssetDetails } from '../../hooks/backend/inventory'
import { toast } from '../../lib/shadcn/sonner'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '../../lib/shadcn/alert-dialog'
import { Badge } from '../../lib/shadcn/badge'
import { Button } from '../../lib/shadcn/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../../lib/shadcn/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../lib/shadcn/card'
import { Input } from '../../lib/shadcn/input'
import { Label } from '../../lib/shadcn/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../lib/shadcn/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../lib/shadcn/table'
import { isManagerRole, metricValue, statusClass, type Asset, type Category, type Profile, type RequestRecord } from './types'

const tagPrefixes: Record<Category, string> = {
  Computing: 'CMP',
  Machinery: 'MCH',
  Vehicles: 'VHC',
  'Office Hardware': 'OFF',
}

type Props = {
  profile: Profile
  assets: Asset[]
  onRefresh: () => void
}

export default function ManagementView({ profile, assets = [], onRefresh }: Props) {
  const isManager = isManagerRole(profile.role)
  const { data: pendingData, loading: pendingLoading, trigger: loadPending } = useGetRequests()
  const { trigger: createAsset, loading: creating } = useCreateAsset()
  const { trigger: reviewRequest, loading: reviewing } = useReviewRequest()
  const { trigger: updateDetails, loading: savingEdit } = useUpdateAssetDetails()
  const { trigger: deleteAsset, loading: deleting } = useDeleteAsset()
  const [assetName, setAssetName] = useState('')
  const [assetCategory, setAssetCategory] = useState<Category>('Computing')
  const [assetValue, setAssetValue] = useState('')
  const [editing, setEditing] = useState<Asset | null>(null)
  const [editName, setEditName] = useState('')
  const [editCategory, setEditCategory] = useState<Category>('Computing')
  const [editValue, setEditValue] = useState('')
  const [pendingDelete, setPendingDelete] = useState<Asset | null>(null)
  const tagPreview = `Auto-generated on save (e.g., ${tagPrefixes[assetCategory]}-001024)`
  const pendingRequests = (pendingData?.requests ?? []) as RequestRecord[]

  useEffect(() => {
    if (isManager) void loadPending()
  }, [isManager, loadPending])

  const registerAsset = async (event: FormEvent) => {
    event.preventDefault()
    if (!assetName.trim()) return
    try {
      const response = await createAsset({ name: assetName, category: assetCategory, value: Number(assetValue) || 0 })
      if (response.result) {
        toast.success(`Asset successfully registered with Tag: ${response.result.asset_tag}`)
      } else if (response.error) {
        toast.error(response.error)
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Asset registration failed.')
    } finally {
      setAssetName('')
      setAssetValue('')
      onRefresh()
    }
  }

  const openEdit = (asset: Asset) => {
    setEditing(asset)
    setEditName(asset.name)
    setEditCategory(asset.category)
    setEditValue(String(asset.value))
  }

  const saveEdit = async (event: FormEvent) => {
    event.preventDefault()
    if (!editing || !editName.trim()) return
    try {
      const response = await updateDetails({ id: editing.id, name: editName, category: editCategory, value: Number(editValue) || 0 })
      if (response.result) {
        toast.success(`${editName} was updated.`)
      } else if (response.error) {
        toast.error(response.error)
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Asset update failed.')
    } finally {
      setEditing(null)
      onRefresh()
    }
  }

  const confirmDelete = async () => {
    if (!pendingDelete) return
    try {
      const response = await deleteAsset({ id: pendingDelete.id })
      if (response.result) {
        if ((response.result as { alreadyDeleted?: boolean }).alreadyDeleted) {
          toast.info('That asset was already removed — the table has been refreshed.')
        } else {
          toast.success(`${pendingDelete.assetTag} was deleted from the inventory.`)
        }
        onRefresh()
      } else if (response.error) {
        toast.error(response.error)
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Asset deletion failed.')
    } finally {
      setPendingDelete(null)
    }
  }

  const handleReview = async (request: RequestRecord, decision: 'approve' | 'reject') => {
    try {
      const response = await reviewRequest({ requestId: request.id, decision })
      if (response.result) {
        if ((response.result as { alreadyProcessed?: boolean }).alreadyProcessed) {
          toast.info('That request was already processed — the list has been refreshed.')
          void loadPending()
        } else {
          toast.success(decision === 'approve' ? `Approved — ${request.assetName} assigned to ${request.requesterEmail}.` : `Rejected — ${request.assetName} returned to available.`)
          void loadPending()
          onRefresh()
        }
      } else if (response.error) {
        toast.error(response.error)
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Request review failed.')
      void loadPending()
    }
  }

  if (!isManager) {
    return <Card className="mx-auto mt-10 max-w-lg shadow-retool-sm"><CardContent className="flex flex-col items-center gap-3 p-10 text-center"><ShieldAlert className="size-8 text-muted-foreground" /><p className="font-medium">Manager access required</p><p className="text-sm text-muted-foreground">Asset registration and request approvals are limited to Inventory Managers and Admins.</p></CardContent></Card>
  }

  return <div className="space-y-6">
    <section className="flex flex-col justify-between gap-3 md:flex-row md:items-end">
      <div><p className="text-sm font-medium text-primary">Management console</p><h2 className="mt-1 text-3xl font-semibold tracking-tight">Asset management & approvals</h2><p className="mt-1 text-sm text-muted-foreground">Register new equipment and process pending user requests.</p></div>
      <div className="flex items-center gap-2 text-xs text-muted-foreground"><ClipboardCheck className="size-3.5" /> {pendingRequests.length} pending review</div>
    </section>
    <section className="grid gap-6 xl:grid-cols-[420px_minmax(0,1fr)]">
      <Card className="h-fit shadow-retool-sm">
        <CardHeader className="border-b border-border"><div><CardTitle className="text-base">Asset registration</CardTitle><CardDescription>Adds equipment directly to the inventory directory.</CardDescription></div></CardHeader>
        <CardContent className="pt-5">
          <form className="space-y-4" onSubmit={(event) => void registerAsset(event)}>
            <div className="space-y-2"><Label htmlFor="auto-asset-tag">Asset tag</Label><Input id="auto-asset-tag" value={tagPreview} readOnly aria-readonly="true" className="bg-muted font-mono text-xs text-muted-foreground" /></div>
            <div className="space-y-2"><Label htmlFor="asset-name">Equipment name</Label><Input id="asset-name" value={assetName} onChange={(event) => setAssetName(event.target.value)} placeholder="e.g. iPad Pro 13”" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Category</Label><Select value={assetCategory} onValueChange={(value) => setAssetCategory(value as Category)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{(['Computing', 'Machinery', 'Vehicles', 'Office Hardware'] as Category[]).map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label htmlFor="asset-value">Asset value</Label><Input id="asset-value" value={assetValue} onChange={(event) => setAssetValue(event.target.value)} placeholder="$0.00" inputMode="decimal" /></div>
            </div>
            <Button type="submit" className="w-full gap-2" disabled={creating}><PackagePlus className="size-4" />{creating ? 'Registering…' : 'Register asset'}</Button>
          </form>
        </CardContent>
      </Card>
      <Card className="min-w-0 shadow-retool-sm">
        <CardHeader className="border-b border-border"><div><CardTitle className="text-base">Pending requests</CardTitle><CardDescription>{pendingLoading ? 'Loading requests…' : `${pendingRequests.length} requests awaiting review`}</CardDescription></div></CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Asset</TableHead><TableHead>Requester</TableHead><TableHead>Justification</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {pendingRequests.length ? pendingRequests.map((request) => <TableRow key={request.id}><TableCell><p className="font-medium text-foreground">{request.assetName}</p><p className="text-xs text-muted-foreground">{request.category} · {new Date(request.requestedAt).toLocaleString()}</p></TableCell><TableCell className="text-sm text-muted-foreground">{request.requesterEmail}</TableCell><TableCell className="max-w-72 truncate text-sm text-muted-foreground">{request.comments}</TableCell><TableCell><div className="flex justify-end gap-2"><Button size="sm" className="gap-1.5" onClick={() => void handleReview(request, 'approve')} disabled={reviewing}><Check className="size-3.5" />Approve</Button><Button size="sm" variant="outline" className="gap-1.5" onClick={() => void handleReview(request, 'reject')} disabled={reviewing}><X className="size-3.5" />Reject</Button></div></TableCell></TableRow>) : <TableRow><TableCell colSpan={4} className="h-28 text-center text-muted-foreground"><Badge variant="secondary">All caught up — no pending requests</Badge></TableCell></TableRow>}
            </TableBody>
          </Table></div>
        </CardContent>
      </Card>
    </section>
    <Card className="min-w-0 shadow-retool-sm">
      <CardHeader className="border-b border-border"><div><CardTitle className="text-base">Registered assets</CardTitle><CardDescription>{assets.length} records — updates in real time after each registration</CardDescription></div></CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto"><Table>
          <TableHeader><TableRow><TableHead>Asset tag</TableHead><TableHead>Asset</TableHead><TableHead>Status</TableHead><TableHead>Assigned to</TableHead><TableHead className="text-right">Value</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
          <TableBody>
            {assets.length ? [...assets].sort((a, b) => b.id - a.id).map((asset) => <TableRow key={asset.id}><TableCell><span className="font-mono text-xs font-semibold">{asset.assetTag}</span></TableCell><TableCell><p className="font-medium text-foreground">{asset.name}</p><p className="text-xs text-muted-foreground">{asset.category}</p></TableCell><TableCell><Badge variant="outline" className={statusClass(asset.status)}>{asset.status}</Badge></TableCell><TableCell className="text-sm text-muted-foreground">{asset.assignedTo ?? 'Unassigned'}</TableCell><TableCell className="text-right font-medium tabular-nums">{metricValue(asset.value)}</TableCell><TableCell><div className="flex justify-end gap-1"><Button size="icon" variant="ghost" aria-label={`Edit ${asset.name}`} onClick={() => openEdit(asset)}><Pencil className="size-4" /></Button><Button size="icon" variant="ghost" aria-label={`Delete ${asset.name}`} onClick={() => setPendingDelete(asset)}><Trash2 className="size-4" /></Button></div></TableCell></TableRow>) : <TableRow><TableCell colSpan={6} className="h-28 text-center text-muted-foreground">No assets registered yet.</TableCell></TableRow>}
          </TableBody>
        </Table></div>
      </CardContent>
    </Card>
    <Dialog open={!!editing} onOpenChange={(open) => { if (!open) setEditing(null) }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle>Edit asset</DialogTitle><DialogDescription>Asset tag {editing?.assetTag} stays fixed; update the details below.</DialogDescription></DialogHeader>
        <form className="space-y-4" onSubmit={(event) => void saveEdit(event)}>
          <div className="space-y-2"><Label htmlFor="edit-asset-tag">Asset tag</Label><Input id="edit-asset-tag" value={editing?.assetTag ?? ''} readOnly aria-readonly="true" className="bg-muted font-mono text-xs text-muted-foreground" /></div>
          <div className="space-y-2"><Label htmlFor="edit-asset-name">Equipment name</Label><Input id="edit-asset-name" value={editName} onChange={(event) => setEditName(event.target.value)} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label>Category</Label><Select value={editCategory} onValueChange={(value) => setEditCategory(value as Category)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{(['Computing', 'Machinery', 'Vehicles', 'Office Hardware'] as Category[]).map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-2"><Label htmlFor="edit-asset-value">Asset value</Label><Input id="edit-asset-value" value={editValue} onChange={(event) => setEditValue(event.target.value)} inputMode="decimal" /></div>
          </div>
          <DialogFooter><Button type="button" variant="outline" onClick={() => setEditing(null)}>Cancel</Button><Button type="submit" disabled={savingEdit}>{savingEdit ? 'Saving…' : 'Save changes'}</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
    <AlertDialog open={!!pendingDelete} onOpenChange={(open) => { if (!open) setPendingDelete(null) }}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {pendingDelete?.assetTag}?</AlertDialogTitle>
          <AlertDialogDescription>{pendingDelete?.name} will be permanently removed from the inventory, along with any equipment requests tied to it. This cannot be undone.</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => void confirmDelete()} disabled={deleting}>{deleting ? 'Deleting…' : 'Delete asset'}</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  </div>
}
