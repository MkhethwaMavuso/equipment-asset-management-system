import { useEffect, useMemo, useState } from 'react'
import {
  Boxes,
  ClipboardCheck,
  LayoutDashboard,
  LogOut,
  PackageSearch,
  ShieldCheck,
} from 'lucide-react'
import { useCurrentUser } from '../hooks/useCurrentUser'
import { useGetInventory } from '../hooks/backend/inventory'
import { Toaster } from '../lib/shadcn/sonner'
import { Badge } from '../lib/shadcn/badge'
import { Button } from '../lib/shadcn/button'
import DashboardView from './ui/DashboardView'
import ManagementView from './ui/ManagementView'
import RequestPortal from './ui/RequestPortal'
import { isManagerRole, type Asset, type Profile, type Role } from './ui/types'

type TabId = 'dashboard' | 'requests' | 'management'

const tabs: Array<{ id: TabId; label: string; shortLabel: string; icon: typeof LayoutDashboard; managerOnly?: boolean }> = [
  { id: 'dashboard', label: 'Dashboard & Asset Inventory', shortLabel: 'Dashboard', icon: LayoutDashboard },
  { id: 'requests', label: 'Request Equipment', shortLabel: 'Requests', icon: PackageSearch },
  { id: 'management', label: 'Asset Management & Approvals', shortLabel: 'Management', icon: ClipboardCheck, managerOnly: true },
]

function fallbackProfile(metadata: Record<string, unknown>, email: string, fullName: string): Profile {
  const possibleRole = metadata['role']
  const role: Role = possibleRole === 'Inventory Manager' || possibleRole === 'Admin' ? possibleRole : 'Standard User'
  return { fullName, email, role }
}

export default function InventoryOperations() {
  const { user, loading } = useCurrentUser()
  const { data: inventoryData, loading: inventoryLoading, error: inventoryError, dataAccessErrors, trigger: loadInventory } = useGetInventory()
  const [activeTab, setActiveTab] = useState<TabId>('dashboard')

  useEffect(() => {
    void loadInventory(undefined, { skipCache: true })
  }, [loadInventory])

  const sessionProfile = useMemo(() => fallbackProfile(
    user?.metadata ?? {},
    user?.email ?? 'unknown@example.com',
    user?.fullName ?? '',
  ), [user])

  const profile = useMemo<Profile>(() => {
    if (inventoryData?.profile) return inventoryData.profile as Profile
    return sessionProfile
  }, [inventoryData, sessionProfile])
  const isManager = isManagerRole(profile.role)

  const refresh = () => {
    void loadInventory(undefined, { skipCache: true })
  }

  const visibleTabs = tabs.filter((tab) => !tab.managerOnly || isManager)

  return <main className="min-h-screen bg-background text-foreground">
    <Toaster position="top-right" />
    <header className="border-b border-border bg-card">
      <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-6 px-6 py-4">
        <div className="flex items-center gap-3"><div className="grid size-10 place-items-center rounded-lg bg-primary text-primary-foreground"><Boxes className="size-5" /></div><div><h1 className="text-lg font-semibold tracking-tight">AssetOps</h1><p className="text-xs text-muted-foreground">Equipment & asset management</p></div></div>
        <div className="flex items-center gap-4">
          <div className="hidden text-right sm:block"><p className="text-sm font-medium">{loading ? 'Loading profile…' : profile.fullName || profile.email}</p><p className="text-xs text-muted-foreground">{profile.email}</p></div>
          <Badge variant="secondary" className="gap-1.5"><ShieldCheck className="size-3.5" />{profile.role}</Badge>
          <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground"><LogOut className="size-4" /> <span className="hidden sm:inline">Log out</span></Button>
        </div>
      </div>
      <nav className="mx-auto flex max-w-[1500px] gap-1 px-6">
        {visibleTabs.map((tab) => {
          const active = activeTab === tab.id
          return <button key={tab.id} onClick={() => setActiveTab(tab.id)} aria-current={active ? 'page' : undefined} className={`-mb-px flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm transition-colors ${active ? 'border-primary font-medium text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}><tab.icon className="size-4" /><span className="hidden md:inline">{tab.label}</span><span className="md:hidden">{tab.shortLabel}</span></button>
        })}
      </nav>
    </header>
    <div className="mx-auto max-w-[1500px] px-6 py-7">
      {inventoryError ? <div className="mb-6 rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">{inventoryError}</div> : null}
      {!inventoryError && dataAccessErrors.length ? <div className="mb-6 rounded-md border border-warning/30 bg-warning/10 px-3 py-2 text-xs text-warning-foreground">Access restricted: {dataAccessErrors.map((item) => item.message).join('; ')}</div> : null}
      {activeTab === 'dashboard' ? <DashboardView profile={profile} assets={(inventoryData?.assets ?? []) as Asset[]} loading={inventoryLoading} onRefresh={refresh} /> : null}
      {activeTab === 'requests' ? <RequestPortal profile={profile} onRefresh={refresh} /> : null}
      {activeTab === 'management' && isManager ? <ManagementView profile={profile} assets={(inventoryData?.assets ?? []) as Asset[]} onRefresh={refresh} /> : null}
    </div>
  </main>
}
